class ContactInfo{
  String id;
  String name;
  String email;
  String address;
  String phone;
  String notes;
  String memberSince;
  String createdAt;
  String cancelSubscriber;
  String active;
  String newSubscriber;

  ContactInfo(this.id, this.name, this.email, this.address, this.phone, this.notes, this.memberSince, this.createdAt, this.cancelSubscriber, this.active, this.newSubscriber);

}